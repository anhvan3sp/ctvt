# SNAPSHOT – CHỐT SỐ / BÁO CÁO

Snapshot dùng để lưu số liệu đã CHỐT theo kỳ (ngày, tháng…).

Nguồn dữ liệu:
- Journal (nhật ký hệ quả)
- Core entities (tham chiếu)

Nguyên tắc bất biến:
- Snapshot READ ONLY
- Không sửa số quá khứ
- Chỉ được ghi bởi JOB chốt
