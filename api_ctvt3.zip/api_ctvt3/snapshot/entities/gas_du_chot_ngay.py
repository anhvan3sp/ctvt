class GasDuChotNgay:
    def __init__(self, ngay, san_pham_id, so_luong_du):
        self.ngay = ngay
        self.san_pham_id = san_pham_id
        self.so_luong_du = so_luong_du
