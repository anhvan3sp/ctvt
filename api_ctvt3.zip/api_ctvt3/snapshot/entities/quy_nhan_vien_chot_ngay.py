class QuyNhanVienChotNgay:
    def __init__(self, ngay, nhan_vien_id, so_du):
        self.ngay = ngay
        self.nhan_vien_id = nhan_vien_id
        self.so_du = so_du
