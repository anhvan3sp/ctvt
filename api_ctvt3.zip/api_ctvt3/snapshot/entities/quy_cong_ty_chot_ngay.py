class QuyCongTyChotNgay:
    def __init__(self, ngay, so_du):
        self.ngay = ngay
        self.so_du = so_du
