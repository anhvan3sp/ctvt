class TonKhoChotNgay:
    def __init__(self, ngay, kho_id, san_pham_id, so_luong_ton):
        self.ngay = ngay
        self.kho_id = kho_id
        self.san_pham_id = san_pham_id
        self.so_luong_ton = so_luong_ton
