from enum import Enum


class LoaiSnapshot(Enum):
    TON_KHO = "TON_KHO"
    GAS_DU = "GAS_DU"
    QUY_CONG_TY = "QUY_CONG_TY"
    QUY_NHAN_VIEN = "QUY_NHAN_VIEN"
