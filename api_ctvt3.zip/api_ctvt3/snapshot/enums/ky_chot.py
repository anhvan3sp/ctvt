from enum import Enum


class KyChot(Enum):
    NGAY = "NGAY"
    THANG = "THANG"
