# MODULE BÁO CÁO

Module `bao_cao` chỉ dùng để ĐỌC DỮ LIỆU.

Nguyên tắc bất biến:
- Không sinh số
- Không ghi DB
- Không làm thay nghiệp vụ

Nguồn dữ liệu:
- snapshot
- view
- reader
