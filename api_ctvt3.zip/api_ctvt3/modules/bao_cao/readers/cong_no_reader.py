# modules/bao_cao/readers/cong_no_reader.py

class CongNoReader:
    def lay_cong_no(self):
        raise NotImplementedError
