# modules/bao_cao/readers/ton_kho_reader.py

class TonKhoReader:
    def lay_ton_kho(self):
        raise NotImplementedError
