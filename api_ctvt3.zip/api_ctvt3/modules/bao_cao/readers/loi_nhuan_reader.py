# modules/bao_cao/readers/loi_nhuan_reader.py

class LoiNhuanReader:
    def lay_loi_nhuan(self):
        raise NotImplementedError
