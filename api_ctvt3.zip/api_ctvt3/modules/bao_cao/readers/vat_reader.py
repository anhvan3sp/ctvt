# modules/bao_cao/readers/vat_reader.py

class VatReader:
    def lay_vat(self):
        raise NotImplementedError
