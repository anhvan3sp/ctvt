# modules/bao_cao/rules/bao_cao_rules.py

class BaoCaoRules:
    @staticmethod
    def duoc_xem_bao_cao() -> bool:
        return True
