# MODULE THU NGÂN

Module `thu_ngan` xử lý nghiệp vụ nhân viên nộp tiền về quỹ công ty.

Phạm vi:
- Ghi nhận việc nhân viên nộp tiền

Sau khi ghi nhận:
- Phát sinh sự kiện để ghi sổ quỹ
- Phục vụ kế toán và báo cáo

Nguyên tắc:
- Không xử lý thu – chi bán hàng
- Chỉ ghi nhận hành động nộp tiền
