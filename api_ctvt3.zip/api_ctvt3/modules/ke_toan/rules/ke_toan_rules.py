# modules/ke_toan/rules/ke_toan_rules.py

class KeToanRules:
    @staticmethod
    def duoc_tao_hoa_don_vat() -> bool:
        return True
