# MODULE KẾ TOÁN

Module `ke_toan` xử lý nghiệp vụ kế toán, VAT và cân thuế.

Phạm vi:
- Tạo hóa đơn VAT cần kê khai
- Phục vụ quyết toán và báo cáo thuế

Nguyên tắc:
- Không sinh tiền
- Không sửa nghiệp vụ bán / nhập
- Chỉ ghi nhận nghĩa vụ thuế
