from enum import Enum


class LoaiKhachHang(Enum):
    LE = "LE"
    DAI_LY = "DAI_LY"
