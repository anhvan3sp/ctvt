from enum import Enum

class DonViTinh(Enum):
    binh = "binh"
    kg = "kg"
    lon = "lon"
    cai = "cai"
