from enum import Enum


class TrangThaiDoiTuong(Enum):
    DANG_SU_DUNG = "DANG_SU_DUNG"
    NGUNG_SU_DUNG = "NGUNG_SU_DUNG"
