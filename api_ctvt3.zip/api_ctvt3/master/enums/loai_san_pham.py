from enum import Enum

class LoaiSanPham(Enum):
    gas_binh = "gas_binh"
    gas_kg = "gas_kg"
    gas_mini = "gas_mini"
    khac = "khac"
