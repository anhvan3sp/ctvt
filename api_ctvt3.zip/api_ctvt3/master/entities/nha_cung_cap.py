from master.enums.trang_thai_doi_tuong import TrangThaiDoiTuong


class NhaCungCap:
    def __init__(self, id: str, ten: str, trang_thai: TrangThaiDoiTuong):
        self.id = id
        self.ten = ten
        self.trang_thai = trang_thai
