class NhanVienKho:
    def __init__(self, nhan_vien_id: str, kho_id: str):
        self.nhan_vien_id = nhan_vien_id
        self.kho_id = kho_id
