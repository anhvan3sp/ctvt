from master.enums.trang_thai_doi_tuong import TrangThaiDoiTuong
from master.enums.loai_san_pham import LoaiSanPham
from master.enums.don_vi_tinh import DonViTinh


class SanPham:
    def __init__(
        self,
        id: str,
        ten: str,
        loai: LoaiSanPham,
        don_vi_tinh: DonViTinh,
        trang_thai: TrangThaiDoiTuong,
    ):
        self.id = id
        self.ten = ten
        self.loai = loai
        self.don_vi_tinh = don_vi_tinh
        self.trang_thai = trang_thai
