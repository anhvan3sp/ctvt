from master.enums.trang_thai_doi_tuong import TrangThaiDoiTuong
from master.enums.loai_khach_hang import LoaiKhachHang


class KhachHang:
    def __init__(
        self,
        id: str,
        ten: str,
        loai: LoaiKhachHang,
        trang_thai: TrangThaiDoiTuong,
    ):
        self.id = id
        self.ten = ten
        self.loai = loai
        self.trang_thai = trang_thai

class KhachHang:
    def __init__(
        self,
        id: int,
        ma_kh: str,
        ten_cua_hang: str,
        dia_chi: str,
        so_dien_thoai: str,
        ma_so_thue: str,
        ghi_chu: str,
        ngay_tao,
    ):
        self.id = id
        self.ma_kh = ma_kh
        self.ten_cua_hang = ten_cua_hang
        self.dia_chi = dia_chi
        self.so_dien_thoai = so_dien_thoai
        self.ma_so_thue = ma_so_thue
        self.ghi_chu = ghi_chu
        self.ngay_tao = ngay_tao

