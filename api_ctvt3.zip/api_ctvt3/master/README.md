# MASTER – DANH MỤC HỆ THỐNG

Master là tập dữ liệu gốc của công ty.

Đặc điểm:
- Không sinh số
- Không ảnh hưởng sổ sách
- Không phát sinh journal / snapshot
- Chỉ dùng làm dữ liệu tham chiếu cho core & modules

Phạm vi:
- Khách hàng
- Nhà cung cấp
- Nhân viên
- Kho hàng
- Sản phẩm

Chức năng:
- Tạo
- Cập nhật
- Ngừng sử dụng

Master KHÔNG:
- Không xử lý nghiệp vụ
- Không cộng trừ tiền
- Không ghi nhật ký
