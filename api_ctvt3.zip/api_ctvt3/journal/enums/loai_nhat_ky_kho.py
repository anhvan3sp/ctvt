from enum import Enum


class LoaiNhatKyKho(Enum):
    NHAP_KHO = "NHAP_KHO"
    XUAT_KHO = "XUAT_KHO"
