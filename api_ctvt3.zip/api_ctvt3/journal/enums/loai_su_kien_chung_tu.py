from enum import Enum


class LoaiSuKienChungTu(Enum):
    HOA_DON_BAN = "HOA_DON_BAN"
    HOA_DON_NHAP = "HOA_DON_NHAP"
    PHIEU_THU = "PHIEU_THU"
    PHIEU_CHI = "PHIEU_CHI"
