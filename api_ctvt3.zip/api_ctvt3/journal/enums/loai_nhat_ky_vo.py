from enum import Enum


class LoaiNhatKyVo(Enum):
    TANG_VO = "TANG_VO"
    GIAM_VO = "GIAM_VO"
