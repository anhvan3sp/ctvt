class NhatKyVo:
    def __init__(
        self,
        chung_tu_id: str,
        so_luong_vo,
        loai_nhat_ky,
        thoi_diem,
    ):
        self.chung_tu_id = chung_tu_id
        self.so_luong_vo = so_luong_vo
        self.loai_nhat_ky = loai_nhat_ky
        self.thoi_diem = thoi_diem
