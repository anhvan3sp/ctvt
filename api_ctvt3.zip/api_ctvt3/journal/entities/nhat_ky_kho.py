class NhatKyKho:
    def __init__(
        self,
        chung_tu_id: str,
        san_pham_id: str,
        so_luong,
        loai_nhat_ky,
        thoi_diem,
    ):
        self.chung_tu_id = chung_tu_id
        self.san_pham_id = san_pham_id
        self.so_luong = so_luong
        self.loai_nhat_ky = loai_nhat_ky
        self.thoi_diem = thoi_diem
