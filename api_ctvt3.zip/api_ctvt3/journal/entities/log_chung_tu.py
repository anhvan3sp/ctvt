class LogChungTu:
    def __init__(
        self,
        chung_tu_id: str,
        loai_su_kien,
        mo_ta: str,
        thoi_diem,
    ):
        self.chung_tu_id = chung_tu_id
        self.loai_su_kien = loai_su_kien
        self.mo_ta = mo_ta
        self.thoi_diem = thoi_diem
